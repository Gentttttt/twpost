<?php
/*

    Coded by Alex
    Telegram : @ALFABRABUS
*/
$token = "5432574559:AAGA0d12eFvFJydtgD7Nw_Vq-6YIjALfsoo";
$chatid = "1881619762";

?>